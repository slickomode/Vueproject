<script setup>
import SearchSection from '../components/SearchSection.vue'
</script>

<template>
  <SearchSection />
</template>

<script>
export default {
  name: 'HomeView',
  components: {
    SearchSection
  },
}
</script>
