<script setup>
import CountryGrid from '../components/CountryGrid.vue'

</script>
<template>
  <CountryGrid />
</template>

<script>
export default {
  name: 'AboutView',
  components: {
    CountryGrid
  },
}
</script>
