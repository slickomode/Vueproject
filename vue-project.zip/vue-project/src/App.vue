<script setup>
import NavBar from './components/NavBar.vue'

</script>

<template>
  <NavBar />
  <router-view></router-view>
</template>
